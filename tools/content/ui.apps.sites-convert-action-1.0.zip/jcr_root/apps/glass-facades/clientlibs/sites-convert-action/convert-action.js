/*
 * Convert to Blocks -- AEM Sites console toolbar action
 * Injects a button into the action bar that opens the blockify tool
 * for the selected page when clicked.
 */
(function($, document, window) {
    'use strict';

    var BLOCKIFY_BASE = 'https://edge--diagram-editor--pstolmar.aem.live/tools/blockify/';
    var BUTTON_ID = 'glass-facades-convert-blocks-btn';

    /** Return the JCR path of the first selected Sites console item. */
    function getFirstSelectedPath() {
        /* The Sites console marks selected cards/rows with
           data-foundation-selections-item; the path lives on the
           nearest ancestor that carries data-foundation-collection-item-id
           or directly on the element itself. */
        var items = document.querySelectorAll('[data-foundation-selections-item]');
        if (!items.length) { return ''; }
        var el = items[0];
        return el.getAttribute('data-foundation-collection-item-id')
            || el.getAttribute('data-granite-collection-item')
            || el.querySelector('[data-foundation-collection-item-id]')
                && el.querySelector('[data-foundation-collection-item-id]')
                       .getAttribute('data-foundation-collection-item-id')
            || '';
    }

    $(document).one('foundation-contentloaded', function() {
        $(document).on('foundation-selections-change', function() {
            var selected = document.querySelectorAll('[data-foundation-selections-item]');
            var $btn = $('#' + BUTTON_ID);

            /* No items selected -- hide the button if present */
            if (!selected.length) {
                $btn.closest('coral-actionbar-item').hide();
                return;
            }

            /* Button already exists -- just make it visible */
            if ($btn.length) {
                $btn.closest('coral-actionbar-item').show();
                return;
            }

            /* First selection event: build and inject the button */
            var $primary = $('coral-actionbar-primary').first();
            if (!$primary.length) { return; }

            var $item = $('<coral-actionbar-item></coral-actionbar-item>');
            var $button = $('<button is="coral-button" variant="quiet" icon="editIn">')
                .attr('id', BUTTON_ID)
                .text('Convert to Blocks');

            $button.on('click', function() {
                var path = getFirstSelectedPath();
                if (path) {
                    window.open(BLOCKIFY_BASE + '?page=' + encodeURIComponent(path), '_blank');
                }
            });

            $item.append($button);
            $primary.append($item);
        });
    });

}(Granite.$, document, window));
